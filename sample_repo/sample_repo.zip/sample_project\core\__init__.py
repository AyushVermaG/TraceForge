"""Core module definitions."""
