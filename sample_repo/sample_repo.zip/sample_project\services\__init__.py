"""Service layer integrations."""
